Multi Business - Business App Flutter

flutter 3.16.4

Dart '>=3.2.3 <4.0.0'


App Code Release Version: 3.4.0

Learn More About Flutter at 👉🏻 https://docs.flutter.dev/

## Test
- Run `flutter test` to execute the unit tests.
- This will run all the test files in the test folder.
- It will ensure that your backend is connected to the app.
- It should show "All tests passed!" in the console.
  