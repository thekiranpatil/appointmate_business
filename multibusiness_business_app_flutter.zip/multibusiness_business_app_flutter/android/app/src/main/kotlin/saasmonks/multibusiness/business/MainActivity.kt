package saasmonks.multibusiness.business

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
