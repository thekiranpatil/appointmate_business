import 'package:multibusiness_business_app_flutter/Appointment/Model/home_all_appointments_response.dart';
import 'package:multibusiness_business_app_flutter/Appointment/Provider/appointments_provider.dart';
import 'package:multibusiness_business_app_flutter/Home/appointment_details_screen.dart';
import 'package:multibusiness_business_app_flutter/Localization/localization_constant.dart';
import 'package:multibusiness_business_app_flutter/Theme/colors.dart';
import 'package:multibusiness_business_app_flutter/Theme/theme.dart';
import 'package:multibusiness_business_app_flutter/Utils/device_utils.dart';
import 'package:multibusiness_business_app_flutter/Utils/lang_const.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:multibusiness_business_app_flutter/Utils/preferences_names.dart';
import 'package:multibusiness_business_app_flutter/Utils/shared_preferences.dart';
import 'package:provider/provider.dart';

class AppointmentsScreen extends StatefulWidget {
  const AppointmentsScreen({super.key});

  @override
  State<AppointmentsScreen> createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends State<AppointmentsScreen> {
  late AppointmentsProvider appointmentsProvider;

  @override
  void initState() {
    super.initState();
    appointmentsProvider = Provider.of<AppointmentsProvider>(context, listen: false);
    Future.delayed(Duration.zero, () {
      appointmentsProvider.callAppointment();
    });
  }

  @override
  Widget build(BuildContext context) {
    appointmentsProvider = Provider.of<AppointmentsProvider>(
      context,
    );
    return ModalProgressHUD(
      inAsyncCall: appointmentsProvider.singleAppointmentLoader,
      progressIndicator: SpinKitThreeBounce(
        color: AppColors.primarySwatch,
        size: 50.0,
      ),
      child: Scaffold(
        backgroundColor: AppColors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          centerTitle: false,
          title: Text(
            getTranslated(context, LangConst.appointments).toString(),
          ),
        ),
        body: appointmentsProvider.appointments.isEmpty && appointmentsProvider.singleAppointmentLoader == false
            ? Center(
                child: Text(getTranslated(context, LangConst.noDataFound).toString()),
              )
            : SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.only(
                    left: Amount.screenMargin,
                  ),
                  child: DataTable(
                    headingRowHeight: 40,
                    headingRowColor: MaterialStateProperty.all<Color>(
                      AppColors.information100,
                    ),
                    columns: [
                      DataColumn(
                        label: Text(
                          getTranslated(context, LangConst.idLabel).toString(),
                          style: TypographySemibold.textTheme.titleSmall,
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          getTranslated(context, LangConst.customerLabel).toString(),
                          style: TypographySemibold.textTheme.titleSmall,
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          getTranslated(context, LangConst.assignTo).toString(),
                          style: TypographySemibold.textTheme.titleSmall,
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          getTranslated(context, LangConst.payment).toString(),
                          style: TypographySemibold.textTheme.titleSmall,
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          getTranslated(context, LangConst.statusLabel).toString(),
                          style: TypographySemibold.textTheme.titleSmall,
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          getTranslated(context, LangConst.serviceAtLabel).toString(),
                          style: TypographySemibold.textTheme.titleSmall,
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          getTranslated(context, LangConst.dateLabel).toString(),
                          style: TypographySemibold.textTheme.titleSmall,
                        ),
                      ),
                      DataColumn(
                        label: Text(
                          getTranslated(context, LangConst.timeLabel).toString(),
                          style: TypographySemibold.textTheme.titleSmall,
                        ),
                      ),
                    ],
                    rows: List.generate(appointmentsProvider.appointments.length, (index) {
                      AppointmentObject data = appointmentsProvider.appointments[index];
                      print(SharedPreferenceHelper.getBoolean(
                        PreferencesNames.timeFormat24,
                      ));
                      return DataRow(
                          cells: [
                        DataCell(
                          onTap: (){
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => AppointmentDetailsScreen(
                                  id: data.id!.toInt(),
                                ),
                              ),
                            );
                          },
                          Text(
                            data.bookingId!,
                            style: TypographyRegular.textTheme.titleSmall!.copyWith(
                              color: AppColors.gray700,
                            ),
                          ),
                        ),
                        DataCell(
                          onTap: (){
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => AppointmentDetailsScreen(
                                  id: data.id!.toInt(),
                                ),
                              ),
                            );
                          },
                          Text(
                            data.userDetails != null ? data.userDetails!.name! : getTranslated(context, LangConst.customerNotFound).toString(),
                            style: TypographyRegular.textTheme.titleSmall!.copyWith(
                              color: AppColors.gray700,
                            ),
                          ),
                        ),
                        DataCell(
                          onTap: (){
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => AppointmentDetailsScreen(
                                  id: data.id!.toInt(),
                                ),
                              ),
                            );
                          },
                          Text(
                            data.empDetails != null ? data.empDetails!.name! : getTranslated(context,LangConst.assignNotFound).toString(),
                            style: TypographyRegular.textTheme.titleSmall!.copyWith(
                              color: AppColors.gray700,
                            ),
                          ),
                        ),
                        DataCell(
                          onTap: (){
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => AppointmentDetailsScreen(
                                  id: data.id!.toInt(),
                                ),
                              ),
                            );
                          },
                          Text(
                            getTranslated(context, data.paymentType!.toLowerCase()).toString(),
                            style: TypographyRegular.textTheme.titleSmall!.copyWith(
                              color: AppColors.gray700,
                            ),
                          ),
                        ),
                        DataCell(
                          onTap: (){
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => AppointmentDetailsScreen(
                                  id: data.id!.toInt(),
                                ),
                              ),
                            );
                          },
                          Text(
                            getTranslated(context,data.bookingStatus.toString().toLowerCase()+"_label").toString(),
                            style: TypographyRegular.textTheme.titleSmall!.copyWith(
                              color: AppColors.gray700,
                            ),
                          ),
                        ),
                        DataCell(
                          onTap: (){
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => AppointmentDetailsScreen(
                                  id: data.id!.toInt(),
                                ),
                              ),
                            );
                          },
                          Text(
                            getTranslated(context, data.bookingAt.toString().toLowerCase()+"_label").toString(),
                            style: TypographyRegular.textTheme.titleSmall!.copyWith(
                              color: AppColors.gray700,
                            ),
                          ),
                        ),
                        DataCell(
                          onTap: (){
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => AppointmentDetailsScreen(
                                  id: data.id!.toInt(),
                                ),
                              ),
                            );
                          },
                          Text(
                            data.date!,
                            style: TypographyRegular.textTheme.titleSmall!.copyWith(
                              color: AppColors.gray700,
                            ),
                          ),
                        ),
                        DataCell(
                          onTap: (){
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => AppointmentDetailsScreen(
                                  id: data.id!.toInt(),
                                ),
                              ),
                            );
                          },
                          Text(
                            SharedPreferenceHelper.getBoolean(PreferencesNames.timeFormat24) == true
                                ? DeviceUtils.convertTo24HourFormat(data.startTime!)
                                : data.startTime!,
                            style: TypographyRegular.textTheme.titleSmall!.copyWith(
                              color: AppColors.gray700,
                            ),
                          ),
                        ),
                      ]);
                    }),
                  ),
                ),
              ),
      ),
    );
  }
}
