class ConstString {
  //TODO Setup : Enter your google map
  static const String googleMapKey = "Enter_Your_google_map_key";
}
