class RegisterResponse {
  RegisterResponse({
    bool? success,
    RegisterData? data,
    String? message,
  }) {
    _success = success;
    _data = data;
    _message = message;
  }

  RegisterResponse.fromJson(dynamic json) {
    _success = json['success'];
    _data = json['data'] != null ? RegisterData.fromJson(json['data']) : null;
    _message = json['message'];
  }

  bool? _success;
  RegisterData? _data;
  String? _message;

  bool? get success => _success;

  RegisterData? get data => _data;

  String? get message => _message;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['success'] = _success;
    if (_data != null) {
      map['data'] = _data?.toJson();
    }
    map['message'] = _message;
    return map;
  }
}

class RegisterData {
  RegisterData({
    String? name,
    String? email,
    String? code,
    String? phone,
    num? role,
    String? language,
    String? provider,
    String? updatedAt,
    String? createdAt,
    num? id,
    String? imagePath,
    String? businessName,
  }) {
    _name = name;
    _email = email;
    _code = code;
    _phone = phone;
    _role = role;
    _language = language;
    _provider = provider;
    _updatedAt = updatedAt;
    _createdAt = createdAt;
    _id = id;
    _imagePath = imagePath;
    _businessName = businessName;
  }

  RegisterData.fromJson(dynamic json) {
    _name = json['name'];
    _email = json['email'];
    _code = json['code'];
    _phone = json['phone'];
    _role = json['role'];
    _language = json['language'];
    _provider = json['provider'];
    _updatedAt = json['updated_at'];
    _createdAt = json['created_at'];
    _id = json['id'];
    _imagePath = json['imagePath'];
    _businessName = json['businessName'];
  }

  String? _name;
  String? _email;
  String? _code;
  String? _phone;
  num? _role;
  String? _language;
  String? _provider;
  String? _updatedAt;
  String? _createdAt;
  num? _id;
  String? _imagePath;
  String? _businessName;

  String? get name => _name;

  String? get email => _email;

  String? get code => _code;

  String? get phone => _phone;

  num? get role => _role;

  String? get language => _language;

  String? get provider => _provider;

  String? get updatedAt => _updatedAt;

  String? get createdAt => _createdAt;

  num? get id => _id;

  String? get imagePath => _imagePath;

  String? get businessName => _businessName;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['email'] = _email;
    map['code'] = _code;
    map['phone'] = _phone;
    map['role'] = _role;
    map['language'] = _language;
    map['provider'] = _provider;
    map['updated_at'] = _updatedAt;
    map['created_at'] = _createdAt;
    map['id'] = _id;
    map['imagePath'] = _imagePath;
    map['businessName'] = _businessName;
    return map;
  }
}
